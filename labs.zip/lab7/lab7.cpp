#include <iostream>
#include <string>

using namespace std;

struct human {
    string firtName, lastName;
    int year;
} humans[4];


human registerHuman(human& h) {
    cout << "\n\nRegister human #" << "\n";
    cout << "First name: ";
    cin >> h.firtName;
    cout << "Last name: ";
    cin >> h.lastName;
    cout << "Birth year: ";
    cin >> h.year;
    return h;
}

bool operator>(human a, human b) {
    if (a.year > b.year)
        return true;
    else
        return false;
};

void swapHumans(int a, int b) {
    human tmp;
    memcpy(&tmp, &humans[a], sizeof(human));
    memcpy(&humans[a], &humans[b], sizeof(human));
    memcpy(&humans[b], &tmp, sizeof(human));
}

int main() {
    for (int i = 0; i < 4; i++) humans[i] = registerHuman(humans[i]);

    cout << "\n\nSorting...\n\n";
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++)
            if (humans[i] > humans[j]) swapHumans(i, j);

    for (int i = 0; i < 4; i++)
        cout << i + 1 << ") First name: " << humans[i].firtName
        << " / Last name: " << humans[i].lastName
        << " / Year: " << humans[i].year << endl;
    return 0;
}
