﻿#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>

int main() {
    FILE* file;
    FILE* write;
    char buff[255];

    file = fopen("peoples.txt", "r");
    write = fopen("out.txt", "w+");

    // Чтение и перебор строк
    while (fgets(buff, sizeof(buff), file) != NULL) {
        int spaces = 0; // Перебор букв в строке
        char year[4]; // Год
        for (int i = 0; i < sizeof(buff); i++) {
            // Запусываем год после 3-его пробела
            if (spaces == 3) {
                for (int j = 0; j < 4; j++) year[j] = buff[i + j];
                break;
            }
            // Если конец строки 
            if (buff[i] == '\0') break;
            // Подсчитываем пробелы
            if (buff[i] == ' ') spaces++;
        }
        // Записываем (если подходит) человека в файлик
        if (spaces == 3 && atoi(year) < 1980) {
            fputs(buff, write);
        }
        //printf("%d %d \n", spaces, atoi(year)); // test
    }

    return 0;
}
