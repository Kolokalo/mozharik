﻿#include "stdio.h"
#include "stdlib.h"
#include "conio.h"
#include "math.h"
#include "locale.h"

int main()
{
	setlocale(LC_ALL, "rus");

	int s[30][30];
	int N, magicConst, g;

	printf("Введите размерность матрицы: ");
	scanf("%d", &N);

	/*Сумма чисел в каждой строке, столбце и на диагоналях называется магической константой, M. 
	Магическая константа нормального волшебного квадрата зависит только от n и определяется формулой*/
	magicConst = (N*((N*N)+1))/2;

	//Вводим элементы матрицы
	printf("Введите значение элемента матрицы: ");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			scanf("%d", &s[i][j]);
		}
	}
	
	//Выводим заполненную матрицу
	printf("\n");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			printf("%d", s[i][j]);
			printf(" ");

			//Разделяем строки матрицы
			if (j == N - 1)
				printf("\n");
		}
	}
	
	//Сумма по вертикали
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			g = g + s[i][j];
			
			if (j == N - 1) {
				if (g != magicConst) {
					printf("Данная матрица не является магически квадратом.\n");
					getch();
					return 0;
				}
				g = 0;
			}
		}
	}
	
	//Сумма по горизонтали
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			g = g + s[j][i];
			
			if (j == N - 1) {
				if (g != magicConst) {
					printf("Данная матрица не является магически квадратом.\n");
					getch();
					return 0;
				}
				g = 0;
			}
		}
	}

	printf("Данная матрица является магически квадратом.\n");
	getch();
	return 0;
}