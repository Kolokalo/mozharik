#include "stdafx.h"
#include "pch.h"
#include "ctype.h"
#include "stdlib.h"
#include "conio.h"
#include "malloc.h"
#include "stdio.h"
#include "locale.h"

long double** multiD(int n, int m, long double **singleMass, long double **doubleMass)
{

	long double res = 0;
	long double **differenceMass;
	differenceMass = (long double**)malloc(n * sizeof(long double*));
	for (int i = 0; i < n; i++)
	{
		differenceMass[i] = (long double*)malloc(m * sizeof(long double));
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			differenceMass[i][j] = doubleMass[i][j] - singleMass[i][j];
		}
	}
	return differenceMass;
}

long double** multiA(int n, int m, long double **singleMass, long double **doubleMass)
{

	long double res = 0;
	long double **additionMass;
	additionMass = (long double**)malloc(n * sizeof(long double*));
	for (int i = 0; i < n; i++)
	{
		additionMass[i] = (long double*)malloc(m * sizeof(long double));
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			additionMass[i][j] = doubleMass[i][j] + singleMass[i][j];
		}
	}
	return additionMass;
}

int main()
{
	int n, m;
	setlocale(LC_ALL, "rus");
	long double **doubleMass, **singleMass;
	long double **differenceMass, **additionMass;

	printf_s("Введите количество строк первой матрицы: ");
	scanf_s("%d", &n);
	printf_s("Введите количество столбцов первой матрицы: ");
	scanf_s("%d", &m);

	// Выделение памяти
	differenceMass = (long double**)malloc(n * sizeof(long double*));
	doubleMass = (long double**)malloc(n * sizeof(long double*));
	singleMass = (long double**)malloc(n * sizeof(long double*));
	additionMass = (long double**)malloc(m * sizeof(long double));

	for (int i = 0; i < n; i++)
	{
		doubleMass[i] = (long double*)malloc(m * sizeof(long double));
		singleMass[i] = (long double*)malloc(m * sizeof(long double));
		differenceMass[i] = (long double*)malloc(m * sizeof(long double));
		additionMass[i] = (long double*)malloc(m * sizeof(long double));
	}

	printf_s("Введите элементы в первую матрицу: ");

	// Ввод элементов массива
	for (int i = 0; i < n; i++)  // Заполняю первую матрицу
	{
		for (int j = 0; j < m; j++)
		{
			scanf_s("%Lf", &doubleMass[i][j]);
		}
	}
	system("cls");
	
	// Считываем символ логического выражения
	char sim;
	printf_s("Введите знак логического выражения: \n1 - '+'\n2 - '-'\n");
	scanf_s("%d", &sim);


	printf_s("Введите количество строк второй матрицы: ");
	scanf_s("%d", &n);
	printf_s("Введите количество столбцов второй матрицы: ");
	scanf_s("%d", &m);

	printf_s("Введите элементы в вторую матрицу: ");

	// Ввод элементов массива
	for (int i = 0; i < n; i++)  // Заполняю вторую матрицу
	{
		for (int j = 0; j < m; j++)
		{
			scanf_s("%Lf", &singleMass[i][j]);
		}
	}
	system("cls");


	if (sim == 2)
	{
		differenceMass = multiD(n, m, singleMass, doubleMass);
		// Вывод элементов массива (результат разности)
		printf_s("Разность двух матриц друг на друга: \n");
		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < m; j++)
			{
				printf_s("%.Lf", differenceMass[i][j]);
				printf_s(" ");

				if (j == n - 1)
					printf("\n");
			}
		}
	}
	else if (sim == 1)
	{
		additionMass = multiA(n, m, singleMass, doubleMass);
		// Вывод элементов массива (результат суммы)
		printf_s("Сумма двух матриц друг на друга: \n");
		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < m; j++)
			{
				printf_s("%.Lf", additionMass[i][j]);
				printf_s(" ");

				if (j == n - 1)
					printf("\n");
			}
		}
	}
	else printf_s("Ошибка!");

	_getch();
}